package com.shopme.admin.test;


import com.shopme.admin.setting.SettingRepository;
import com.shopme.common.entity.setting.Setting;
import com.shopme.common.entity.setting.SettingCategory;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.annotation.Rollback;

import java.util.List;

import static org.assertj.core.api.AssertionsForClassTypes.assertThat;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@Rollback(false)
public class SettingRepositoryTests {
    @Autowired
    SettingRepository repo;
    @Test
    public void testCreateGeneralSettings(){
        Setting siteName = new Setting("SITE_NAME","Shopme", SettingCategory.GENERAL);
        Setting siteLogo = new Setting("SITE_LOGO","Shopme.png", SettingCategory.GENERAL);
        Setting copyright = new Setting("COPYRIGHT","Copyright (C) 2024 Shopme Ltd.", SettingCategory.GENERAL);

        repo.saveAll(List.of(siteLogo,copyright));



    }
}
