package com.shopme.admin.user;

import com.shopme.common.entity.Role;
import com.shopme.common.entity.User;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.AutoConfigureDataJpa;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.test.annotation.Rollback;

import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.InstanceOfAssertFactories.list;

@DataJpaTest(showSql = false)
@AutoConfigureTestDatabase(replace= AutoConfigureTestDatabase.Replace.NONE)
@Rollback(false)
public class UserRepositoryTests {
    @Autowired
    private UserRepository repo;
    @Autowired
    private TestEntityManager entityManager;

    @Test
    public void testCreateUser(){
        Role roleAdmin= entityManager.find(Role.class,1);
        User userNamNH = new User("nam@codejava.net","nam2020","Nam","Ha Minh");
        userNamNH.addRole(roleAdmin);
        User savedUser =repo.save(userNamNH);


    }
    @Test
    public void testCreateNewUserWithTwoRole(){
        User userQuang= new User("trunggmail.com","trungdb","Trung","Nguyen Van");
        Role roleEditor = new Role(3,"assistant","ko lam gi ca");
        Role roleShipper= new Role(2);
        userQuang.addRole(roleEditor);
        userQuang.addRole(roleShipper);
        User savedUser = repo.save(userQuang);
    }
    @Test
    public void testGetUserByEmail(){
        String email ="quangteo7112003@gmail.com";
        User user = repo.getUserByEmail(email);
        assertThat(user).isNotNull();
    }

    @Test
    public void testListFirstPage(){
        int pageNumber=0;
        int pageSize=4;
        Pageable pageable= PageRequest.of(pageNumber,pageSize);
        Page<User> page =repo.findAll(pageable);
        List<User> listUsers= page.getContent();
        listUsers.forEach(user->System.out.println(user));
        assertThat(listUsers.size()).isEqualTo(pageSize);
    }

    @Test
    public void testSearchUsers(){
        String keyword= "bruce";
        int pageNumber=0;
        int pageSize=4;
        Pageable pageable= PageRequest.of(pageNumber,pageSize);
        Page<User> page =repo.findAll(keyword,pageable);
        List<User> listUsers= page.getContent();
        listUsers.forEach(user->System.out.println(user));
        assertThat(listUsers.size()).isGreaterThan(0);
    }



}
