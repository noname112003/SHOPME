$(document).ready(function() {
	$("#productList").on("click", ".linkRemove", function(e) {
		e.preventDefault();
		
		if (doesOrderHaveOnlyOneProduct()) {
			// alert("Could not remove product. The order must have eat least one product.")
			showWarningModal("Could not remove product. The order must have eat least one product.");
		} else {
			removeProduct($(this));		
			// updateOrderAmounts();
		}
	});
});

function removeProduct(link) {
	rowNumber = link.attr("rowNumber");
	$("#row" + rowNumber).remove();
	$("#blankLine" + rowNumber).remove();
	
	$(".divCount").each(function(index, element) {
		element.innerHTML = "" + (index + 1);
	});

}

function doesOrderHaveOnlyOneProduct() {
	productCount = $(".hiddenProductId").length;//trả về số lượng thẻ có class là hiddenProductId
	return productCount == 1;
}

