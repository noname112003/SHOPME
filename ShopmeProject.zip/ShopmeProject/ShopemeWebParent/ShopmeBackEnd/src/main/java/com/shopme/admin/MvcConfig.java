package com.shopme.admin;

import com.shopme.admin.paging.PagingAndSortingArgumentResolver;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

@Configuration
public class MvcConfig implements WebMvcConfigurer {

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        String dirName="user-photos";
        Path userPhotoDir= Paths.get("user-photos");
        String userPhotosPath= userPhotoDir.toFile().getAbsolutePath();
        registry.addResourceHandler("/"+dirName+"/**").addResourceLocations("file:/"+userPhotosPath+"/");

        String categoryImagesDirName="category-images";
        Path categoryImageDir= Paths.get(categoryImagesDirName);
        String categoryImagesPath= categoryImageDir.toFile().getAbsolutePath();
        registry.addResourceHandler("/"+categoryImagesDirName+"/**").addResourceLocations("file:/"+categoryImagesPath+"/");

        String brandImagesDirName="brand-images";
        Path brandImageDir= Paths.get(brandImagesDirName);
        String brandImagesPath= brandImageDir.toFile().getAbsolutePath();
        registry.addResourceHandler("/"+brandImagesDirName+"/**").addResourceLocations("file:/"+brandImagesPath+"/");

        String productImagesDirName="product-images";
        Path productImageDir= Paths.get(productImagesDirName);
        String productImagesPath= productImageDir.toFile().getAbsolutePath();
        registry.addResourceHandler("/"+productImagesDirName+"/**").addResourceLocations("file:/"+productImagesPath+"/");

        String siteLogo = "site-logo";
        Path siteLogoDir= Paths.get(siteLogo);
        String siteLogoPath= siteLogoDir.toFile().getAbsolutePath();
        registry.addResourceHandler("/"+siteLogo+"/**").addResourceLocations("file:/"+siteLogoPath+"/");

    }

    @Override
    public void addArgumentResolvers(List<HandlerMethodArgumentResolver> resolvers) {
        resolvers.add(new PagingAndSortingArgumentResolver());
    }
}
