package com.shopme.shopmeproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopmeProjectApplicationTests {

    @Test
    void contextLoads() {
    }

}
