package com.shopme.common.entity.order;

public enum PaymentMethod {
    COD
}
