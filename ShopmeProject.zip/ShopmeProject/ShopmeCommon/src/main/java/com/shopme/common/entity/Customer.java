package com.shopme.common.entity;

import jakarta.persistence.*;

import java.util.Date;
import java.util.Set;

@Entity
@Table(name = "customers")
public class Customer extends AbstractAddressWithCountry{

    @Column(nullable = false, unique = true, length = 45)
    private String email;

    @Column(nullable = false, length = 64)
    private String password;
    @Column(name = "verification_code", length = 64)
    private String verificationCode;

    private boolean enabled;

    @Column(name = "created_time")
    private Date createdTime;
    @Column(name = "reset_password_token", length = 30)
    private String resetPasswordToken;

//    @OneToMany(mappedBy = "customer")
//    private Set<Customer> customers;


    public Customer() {
    }

    public Customer(Integer id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    public String getVerificationCode() {
        return verificationCode;
    }

    public void setVerificationCode(String verificationCode) {
        this.verificationCode = verificationCode;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public Date getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(Date createdTime) {
        this.createdTime = createdTime;
    }
    public String getFullName() {
        return firstName + " " + lastName;
    }
    public String getResetPasswordToken() {
        return resetPasswordToken;
    }

    public void setResetPasswordToken(String resetPasswordToken) {
        this.resetPasswordToken = resetPasswordToken;
    }

    @Transient
    public String getAddress(){
        String address = firstName;


        if(lastName != null && !lastName.isEmpty()) address +=" "+lastName;
        if(!addressLine1.isEmpty())  address+= ", "+ addressLine1;
        if(addressLine2 != null && !addressLine2.isEmpty()) address +=" "+addressLine2;
        if(!city.isEmpty())  address+= ", "+ city;
        if(state != null && !state.isEmpty()) address +=", "+state;

        address += country.getName();

        if(!postalCode.isEmpty()) address += ". Postal Code: "+ postalCode;
        if(!phoneNumber.isEmpty()) address += ". Phone Number: "+ phoneNumber;


        return address;
    }

}
